# depmedic Vendor Dossier PDF

Thanks for buying.

Inside this ZIP:

- **`sample-lodash.pdf`** - the full sample dossier for `lodash` (the
  format your custom dossier will follow). 6-8 pages, identical engine.
- **`sample-lodash.html`** - browser-friendly twin of the same dossier.
- **`sample-lodash.raw.json`** - the underlying snapshot data so you can
  audit / re-run the analysis yourself.
- **`HOW_TO_REQUEST.md`** - claim your dossier for any npm package.

## Claim your custom dossier (free, included)

You bought one custom dossier with this purchase. To claim it:

1. Reply to your Polar receipt email (or email **depmedic.dev@gmail.com**)
2. Subject line: `Vendor Dossier - <package-name>`
3. Body: just the npm package name, e.g. `react`, `@tanstack/react-query`,
   `some-internal-private-pkg` (private packages need a one-time data
   share - see HOW_TO_REQUEST.md).

Delivery: within 24 hours, usually same day. The dossier is generated
from public sources (api.npms.io + npm registry + osv.dev) and emailed
back as a PDF + the raw JSON snapshot.

## What the dossier covers

1. Executive summary + 0-100 health score (popularity, maintenance, quality, risk)
2. Identity + ownership (publisher, maintainers, license, repo, types)
3. Adoption signal (downloads, dependents, stars, issue close rate)
4. Release cadence (last 12 versions + days between)
5. Known security advisories (OSV.dev) + severity + status
6. Decision matrix (load-bearing / peripheral / defer / sunset)
7. Vendor questionnaire (what to ask the maintainer in a security review)
8. Operational mitigations (pin, mirror, watch, allowlist)
9. Sources + methodology

## Refunds

Within 7 days of purchase, no questions asked. Email
depmedic.dev@gmail.com.

## Related

- **Org Dep Health Monitor** ($19/mo) - re-runs the same analysis nightly
  for every package across your org, emails on grade slips. Pays for
  itself the first time it surfaces a sneaky deprecation.
- **Live snapshots** for 100+ popular packages, free, refresh nightly:
  <https://depmedicdev-byte.github.io/health/>.
- **`depmedic` CLI** for vulnerability triage on `npm audit` output:
  `npx depmedic` - free, MIT.

depmedic.dev@gmail.com
