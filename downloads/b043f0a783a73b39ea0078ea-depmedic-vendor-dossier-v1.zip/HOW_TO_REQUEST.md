# How to claim your custom Vendor Dossier

You get **one custom dossier** per Vendor Dossier PDF purchase.

## Step 1: send the package name

Reply to your Polar receipt email, or send a fresh email to
**depmedic.dev@gmail.com**, with:

- Subject: `Vendor Dossier - <package-name>`
- Body: the npm package name, exactly as on npm. That is all.

## Step 2: receive the dossier

Within 24 hours (usually same day) you get back:

- `<package>.pdf` - the dossier (6-8 pages, same format as the lodash sample)
- `<package>.raw.json` - the source snapshot data

## Public packages

No extra info needed; the dossier is generated from api.npms.io,
registry.npmjs.org, and osv.dev.

## Private / internal packages

We do not have access to your private registry. To dossier a private
package you have two options:

1. **Send the registry data yourself.** Run:
   ```
   npm view <pkg> --json > info.json
   npm audit --json > audit.json
   ```
   and email both files. We assemble the dossier from those.
2. **Skip the request and ship the dossier on a public near-equivalent**
   (e.g. the OSS package your private one wraps). Useful for vendor
   reviews where you only need the upstream signal.

## Want more than one dossier per purchase?

- Buy multiple Vendor Dossier PDF entries (each = +1 custom dossier).
- Or upgrade to **Org Dep Health Monitor** ($19/mo) which monitors the
  full set of packages across your repos automatically:
  <https://buy.polar.sh/> (link in the receipt).

## Refunds

7-day no-questions refund. Email depmedic.dev@gmail.com.
