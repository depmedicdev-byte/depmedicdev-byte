# Security-First Workflows Pack v1.0.0

Five drop-in GitHub Actions workflows for the security-conscious team.
No long-lived secrets, signed artifacts, build provenance, secret scanning.

## Files

| File                                | What it does                                                          |
| ----------------------------------- | --------------------------------------------------------------------- |
| oidc-aws-deploy.yml                 | Deploy to AWS via OIDC (zero AWS keys in CI)                          |
| oidc-gcp-deploy.yml                 | Deploy to GCP via Workload Identity Federation                        |
| slsa-l3-build-provenance.yml        | SLSA Level 3 attestation on every release tag                         |
| signed-container-release.yml        | Container release: build + Trivy scan + cosign sign + provenance      |
| secret-scanning.yml                 | gitleaks + trufflehog on PRs, pushes, weekly drift                    |

## Why this pack matters in 2026

- **OIDC everywhere.** Long-lived AWS / GCP / Azure keys in CI secrets
  are the #1 source of supply-chain incidents. OIDC removes the credential
  entirely - GitHub mints a short-lived token per run.
- **Signed releases.** Sigstore (Fulcio + Rekor) is now the de-facto
  standard. Adopting cosign signing on container images is a 5-minute
  change and unlocks downstream consumers verifying you in their own CI.
- **SLSA Level 3.** Build provenance proves the artifact was built by
  GitHub Actions from the commit you claim. Required by an increasing
  number of enterprise vendor questionnaires.

## Setup per file

### oidc-aws-deploy.yml
1. In AWS, create an OIDC identity provider for
   `token.actions.githubusercontent.com`.
2. Create an IAM role with the trust policy at the bottom of the file
   (replace `YOUR_ORG/YOUR_REPO`).
3. Attach the AWS permissions the role actually needs (S3, CloudFront, etc.).
4. Update the `role-to-assume` ARN in the workflow.

### oidc-gcp-deploy.yml
1. Create a Workload Identity Pool in GCP:
   `gcloud iam workload-identity-pools create gh-pool --location=global`.
2. Create an OIDC provider in the pool with issuer
   `https://token.actions.githubusercontent.com`.
3. Bind a service account to the pool with
   `gcloud iam service-accounts add-iam-policy-binding`.
4. Update the workflow with your provider path and SA email.

### slsa-l3-build-provenance.yml
1. Make sure your release artifacts are produced before the `hash` step.
2. Tag a release: `git tag v1.0.0 && git push --tags`.
3. The provenance shows up as a release asset `*.intoto.jsonl`.
4. Verify with `slsa-verifier verify-artifact ...`.

### signed-container-release.yml
1. Make sure `packages: write` is on the workflow.
2. Tag a release. The image is pushed to `ghcr.io/<repo>:<tag>`,
   signed keyless via cosign, and a build attestation is pushed to the
   registry.
3. Verify with `cosign verify ghcr.io/<repo>:<tag> ...`.

### secret-scanning.yml
1. Create a Gitleaks license (free for OSS) at gitleaks.io.
2. Add as repo secret `GITLEAKS_LICENSE` (or use the generic
   GITHUB_TOKEN for OSS repos as in this template).
3. The weekly cron catches secrets that snuck through PR review.

## What is NOT in this pack (and why)

- **Snyk / Veracode** - paid, out-of-scope. Trivy + the OIDC-based
  flows here cover the same surface for free.
- **Renovate config** - separate concern; covered in the Pre-PR
  Checklist Pack.
- **Branch protection** - this is a setting, not a workflow. Document
  in your runbook.

## License

See LICENSE.txt.
