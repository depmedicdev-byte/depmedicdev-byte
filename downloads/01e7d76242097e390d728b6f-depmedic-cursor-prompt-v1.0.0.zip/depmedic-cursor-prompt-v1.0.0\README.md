# depmedic Senior Dev System Prompt

A single, hand-tuned system prompt that makes any chat-based AI tool act like
a senior software engineer with hard taste and tight token discipline.

Drop it into a "System Prompt" or "Custom Instructions" field. It works with
Cursor, Claude, ChatGPT, Gemini, and most local-LLM frontends that allow a
system prompt.

## What you get

- `senior-dev-system.md` - the prompt, ~80 lines, ready to paste.
- `USAGE.md` - notes on which tools accept system prompts and where to put
  them.

## Why

Default model output is fine for greenfield demos. On a real codebase it tends
to apologize, restate context, rewrite working code as a side effect of a
small ask, use marketing words, and prefer breadth over depth.

This prompt is calibrated against those failure modes.

## License

Single buyer, unlimited projects. See `LICENSE-COMMERCIAL.txt`. Do not
re-publish as a standalone file.

## Buy more

This is a single-prompt drop. The full
[depmedic Senior Dev Cursor Rules](https://polar.sh/depmedicdev/cursor-rules)
pack ($7) bundles 24 `.cursorrules` files and 3 prompts including this one,
USAGE blends per stack, and free updates.
