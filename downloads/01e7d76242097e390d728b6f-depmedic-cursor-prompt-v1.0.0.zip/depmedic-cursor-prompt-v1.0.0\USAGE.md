# USAGE

## Cursor

Cursor: Settings > Rules > User Rules. Paste the full prompt. Save.
For project-scoped use, place a `.cursorrules` file in the project root with
the same contents.

## Claude (claude.ai)

Settings > Profile > Custom Instructions. Paste. Save. Applies to every new
conversation.

## ChatGPT

Settings > Personalization > Custom Instructions > "How would you like
ChatGPT to respond?". Paste. Save.

## Local LLM frontends

Most (LM Studio, Open WebUI, Jan, Ollama with a Modelfile) accept a system
prompt at session start or as a default. Place this prompt there.

## Tweaking

The prompt is a hard-banned-phrases list plus voice + defaults. If your team
has its own banned-words list, append it to the "Hard bans" section. Don't
remove items unless you have a reason; each one is in there because models
default to it.

## Updates

Latest version at <https://polar.sh/depmedicdev/cursor-prompt>.
