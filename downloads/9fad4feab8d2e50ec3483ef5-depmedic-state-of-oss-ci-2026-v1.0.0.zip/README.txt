State of OSS CI Hygiene 2026 - Edition 1
by depmedic

Files:
- state-of-oss-ci-2026.pdf       (primary report, ~12 pages)
- state-of-oss-ci-2026.html      (browser-friendly twin)
- leaderboard-snapshot.json      (raw input data, this snapshot)
- LICENSE.txt

Free updates within v1.x as the dataset evolves.
Live data and day-over-day deltas at:
  https://depmedicdev-byte.github.io/leaderboard.html

Errata / questions: depmedic.dev@gmail.com