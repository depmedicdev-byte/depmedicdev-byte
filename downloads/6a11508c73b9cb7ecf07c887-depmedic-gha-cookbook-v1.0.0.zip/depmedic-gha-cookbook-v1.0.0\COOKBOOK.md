# Cut Your CI Bill

30 patterns for cheaper, faster, less leaky GitHub Actions workflows.

The patterns assume the standard GitHub-hosted runner pricing model where
`ubuntu-latest` is the unit cost, `windows-latest` is 2x, and
`macos-latest` is 10x. Adjust the dollar arithmetic to your plan, but the
relative numbers hold.

## How to read this

Each pattern has the same shape:

- **Why** - the failure mode it addresses.
- **Apply** - the smallest YAML change that fixes it.
- **Catch** - the gotcha that shows up if you apply it carelessly.

Patterns are ordered by approximate cost-impact, highest first. If you only
have an hour, do patterns 1 through 7.

---

## Cost patterns

### 1. Cancel superseded runs with concurrency

**Why.** Without a concurrency block, a fast push-to-push-to-push streak
runs CI three times for the same final state. On a busy repo with 50
pushes/day this is the single biggest leak.

**Apply.** Top of every workflow that runs on `push` or `pull_request`:

```yaml
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
```

**Catch.** For deploy workflows you usually want
`cancel-in-progress: false` so a deploy in progress finishes; concurrency
just queues the next one.

### 2. Use `ubuntu-latest` unless you genuinely need macOS or Windows

**Why.** `macos-latest` runs 10x the cost. `windows-latest` 2x. A test job
that "happens to be" on macOS doubles or worse the bill of every PR.

**Apply.** Audit `runs-on:` lines. macOS is required only when you build
or sign Apple binaries (`xcodebuild`, `codesign`, `notarytool`). Windows
is required only for native Windows code paths.

**Catch.** Cross-platform tests should still exist. Move them to a nightly
schedule or a `workflow_dispatch` job rather than running every PR.

### 3. Cache language tooling

**Why.** Without `cache:`, `setup-node`, `setup-python`, `setup-java`,
`setup-go`, and `setup-dotnet` re-download dependencies on every run. 30
to 90 seconds per job, sometimes more.

**Apply.**

```yaml
- uses: actions/setup-node@v4
  with:
    node-version: 20
    cache: npm

- uses: actions/setup-python@v5
  with:
    python-version: '3.12'
    cache: pip
```

**Catch.** Cache keys depend on lockfiles. If the lockfile path is
non-standard, set `cache-dependency-path`.

### 4. Set `timeout-minutes` on every job

**Why.** The default is 360 minutes (6 hours). A hung step burns six hours
of paid runner time before GitHub kills it.

**Apply.** On every job:

```yaml
jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 15
```

**Catch.** Tune per job. Long-running builds deserve more headroom; tests
deserve less.

### 5. `paths:` filters on heavy workflows

**Why.** A 20-minute integration suite has no business running when a PR
only touched the README.

**Apply.**

```yaml
on:
  pull_request:
    paths:
      - 'src/**'
      - 'tests/**'
      - 'package.json'
      - 'package-lock.json'
```

**Catch.** Branch-protection rules that require this workflow won't see a
status if it skips. Use `paths-ignore` to skip the workflow entirely, or
keep a "always run" stub job that posts a green status when the heavy job
isn't needed.

### 6. Trim the matrix on PRs, full matrix on schedule

**Why.** A 9-cell matrix runs 9x. A PR doesn't need 9 environments to
catch the typo a reviewer is going to find anyway.

**Apply.** Two workflows:

```yaml
# .github/workflows/pr.yml
on: pull_request
jobs:
  fast:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        node: [20]
    steps: [...]

# .github/workflows/nightly.yml
on:
  schedule:
    - cron: '0 4 * * *'
jobs:
  full:
    runs-on: ${{ matrix.os }}
    strategy:
      matrix:
        os: [ubuntu-latest, macos-latest, windows-latest]
        node: [18, 20, 22]
    steps: [...]
```

**Catch.** When the nightly fails, someone has to look at it. Wire a
notification so failures are visible.

### 7. Short artifact retention

**Why.** `actions/upload-artifact` defaults to your repo's retention,
often 90 days. Storage is billed.

**Apply.**

```yaml
- uses: actions/upload-artifact@v4
  with:
    name: build
    path: dist
    retention-days: 7
```

**Catch.** Releases and reproducibility evidence may need longer.

### 8. Skip duplicate runs on push + pull_request

**Why.** A PR push fires both `push` (to the branch) and `pull_request`
events. Same workflow runs twice.

**Apply.** Either:

```yaml
on:
  push:
    branches: [main]   # only run push trigger on main
  pull_request:
```

or guard explicitly:

```yaml
jobs:
  build:
    if: github.event_name == 'pull_request' || github.ref == 'refs/heads/main'
```

**Catch.** If your team relies on push-to-feature-branch CI for solo
work, the first option will surprise them.

### 9. Replace expensive `act-runner` startup with `setup-buildx-action`

**Why.** `docker/setup-buildx-action` is faster than re-installing buildx
in every job. It also enables a remote builder if you have one.

**Apply.**

```yaml
- uses: docker/setup-buildx-action@v3
```

**Catch.** Some images need `setup-qemu-action` first for cross-arch
builds.

### 10. Cache Docker layers with the GitHub Actions cache backend

**Why.** Without layer caching, every Docker build re-runs every step.

**Apply.**

```yaml
- uses: docker/build-push-action@v6
  with:
    context: .
    push: false
    cache-from: type=gha
    cache-to: type=gha,mode=max
```

**Catch.** GitHub Actions cache is shared across workflows in the repo.
Cache poisoning across branches is a known concern; isolate cache keys
where it matters.

---

## Speed patterns

### 11. Parallelize tests with sharding

**Why.** A 20-minute test suite split 4 ways is 5 minutes wall clock.

**Apply.** Most test runners accept a shard flag. Vitest:

```yaml
strategy:
  matrix:
    shard: [1, 2, 3, 4]
steps:
  - run: npx vitest --shard=${{ matrix.shard }}/4
```

**Catch.** Setup time is paid per shard. Sharding only wins when test
runtime exceeds startup cost.

### 12. Hoist common setup into a composite action

**Why.** When five jobs each spend 30 seconds checking out, installing
Node, and `npm ci`, that's 2.5 minutes of duplicated work.

**Apply.** Create `.github/actions/setup/action.yml`:

```yaml
name: setup
runs:
  using: composite
  steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-node@v4
      with:
        node-version: 20
        cache: npm
    - run: npm ci
      shell: bash
```

Use it: `- uses: ./.github/actions/setup`.

**Catch.** Composite actions can't read secrets unless you pass them as
inputs explicitly.

### 13. `npm ci --prefer-offline --no-audit --progress=false`

**Why.** `npm ci` defaults are CI-hostile. The audit step and the progress
spinner each cost a few seconds; `--prefer-offline` skips network when the
cache is warm.

**Apply.** Replace bare `npm ci` with the flag set above.

**Catch.** None.

### 14. Run lints, types, and tests in parallel jobs

**Why.** Sequential `lint -> typecheck -> test` adds three minutes when
each step takes one. Three parallel jobs run in the time of the slowest.

**Apply.** Three jobs sharing a setup composite:

```yaml
jobs:
  lint:
    steps: [{ uses: ./.github/actions/setup }, { run: npm run lint }]
  types:
    steps: [{ uses: ./.github/actions/setup }, { run: npm run typecheck }]
  test:
    steps: [{ uses: ./.github/actions/setup }, { run: npm test }]
```

**Catch.** You pay the setup cost three times. Worth it when each step
is more expensive than setup.

### 15. Use `actions/cache` for ad-hoc directories

**Why.** Things like `.next/cache`, `target/`, `~/.gradle/caches` benefit
from being cached even when no setup-* action covers them.

**Apply.**

```yaml
- uses: actions/cache@v4
  with:
    path: |
      .next/cache
      ~/.cache/turbo
    key: ${{ runner.os }}-cache-${{ hashFiles('**/package-lock.json') }}
    restore-keys: |
      ${{ runner.os }}-cache-
```

**Catch.** Cache keys that include too much (e.g. a daily date) miss too
often. Keys that include too little hit stale entries.

### 16. Parallel matrix without job dependencies

**Why.** `needs:` chains add round-trip latency. The runner pool warms
slow.

**Apply.** Define independent jobs side by side. Use `needs:` only when
job B genuinely needs job A's output.

**Catch.** Sequential gates exist for reasons (e.g. lint blocks build to
fail fast). Don't break those.

### 17. Smaller checkout

**Why.** Default `actions/checkout` clones with depth 1, which is fast.
But many setups use `fetch-depth: 0` because some tool demanded it five
years ago and no one revisited.

**Apply.** Audit every `fetch-depth: 0`. Keep only where commitlint,
semantic-release, lerna, or a real git-history-using tool needs it.

**Catch.** Tools like `nx affected` may need history. Check each one.

### 18. Skip the GitHub Pages step on PRs

**Why.** Building docs on every PR but only deploying on main wastes the
build minutes for PR runs that are never published.

**Apply.**

```yaml
- name: Build docs
  if: github.ref == 'refs/heads/main'
  run: npm run docs:build
```

**Catch.** Doc breakage won't be caught at PR time. Acceptable for many
teams; not for docs-as-code teams.

### 19. Use `pnpm` if your team can swap

**Why.** `pnpm install` is typically 2-3x faster than `npm ci` on cold
caches and uses much less disk.

**Apply.** Adopt `pnpm`, set `cache: pnpm` in setup-node.

**Catch.** Migration is non-trivial for monorepos. Worth it; don't do it
on a Friday.

### 20. Skip CI on draft PRs

**Why.** Draft PRs sometimes update many times before being marked ready.

**Apply.**

```yaml
on:
  pull_request:
    types: [opened, synchronize, reopened, ready_for_review]

jobs:
  build:
    if: github.event.pull_request.draft == false
```

**Catch.** Authors who use draft PRs as a way to get early CI feedback
will be surprised.

---

## Security patterns

### 21. Top-level `permissions: contents: read`

**Why.** The default `GITHUB_TOKEN` permission set is whatever the repo's
"Workflow permissions" setting says, often "read and write all". Any
malicious dependency in a build can use the token to write.

**Apply.** Top of every workflow:

```yaml
permissions:
  contents: read
```

Add scopes per job that needs more (`pull-requests: write`,
`packages: write`, etc).

**Catch.** Some actions assume write access and fail loudly when scoped
down. Add the specific scope they need.

### 22. Pin third-party actions to a SHA, not a tag

**Why.** Tags are mutable. The author of `cool-action@v3` can rewrite
the tag to point at malicious code, and your workflow runs it. SHAs are
immutable.

**Apply.**

```yaml
- uses: third-party/action@692973e3d937129bcbf40652eb9f2f61becf3332  # v3.1.0
```

**Catch.** Use a tool like `pinact` or Renovate to keep SHAs current.
Stale SHAs are a different problem.

### 23. Don't expose secrets to actions you can't audit

**Why.** Anything you set in `env:` is visible to every step in the job.
A malicious step in a third-party action exfiltrates them.

**Apply.** Only set secrets at the step level for steps that need them.

```yaml
- name: Deploy
  run: ./deploy.sh
  env:
    DEPLOY_KEY: ${{ secrets.DEPLOY_KEY }}
```

**Catch.** Some actions read secrets as inputs. Verify their source
before passing them.

### 24. `pull_request_target` is dangerous; treat it as such

**Why.** It runs with the base branch's secrets and its workflow file,
not the PR's. Combined with checking out PR code, you can run untrusted
code with full secret access.

**Apply.** Either don't use `pull_request_target`, or never `checkout`
the PR head, or use a hard allow-list of trusted PR authors.

**Catch.** Bots and templates often use `pull_request_target` because
the PR-level token can't write back. Read each one carefully.

### 25. Use `OIDC` for cloud creds, not long-lived secrets

**Why.** Hard-coding `AWS_ACCESS_KEY_ID` in secrets means a leak rotates
slowly. OIDC issues short-lived tokens per workflow run.

**Apply.** AWS:

```yaml
permissions:
  id-token: write
  contents: read
steps:
  - uses: aws-actions/configure-aws-credentials@v4
    with:
      role-to-assume: arn:aws:iam::ACCOUNT:role/GitHubActions
      aws-region: us-east-1
```

**Catch.** Requires IAM trust policy on AWS side; one-time setup.

---

## Maintenance patterns

### 26. Reusable workflows for repeated shapes

**Why.** Ten repos with near-identical "lint-typecheck-test" workflows
drift. Bug fixes have to land ten times.

**Apply.** Define `.github/workflows/_node-checks.yml` with `on:
workflow_call:` in a central repo. Call it from each repo:

```yaml
jobs:
  checks:
    uses: org/.github/.github/workflows/_node-checks.yml@v1
    with:
      node-version: 20
```

**Catch.** Versioning matters. Pin to a tag, not `@main`.

### 27. Dependabot grouped updates

**Why.** Twelve PRs a week from Dependabot drowns the queue.

**Apply.** `.github/dependabot.yml`:

```yaml
version: 2
updates:
  - package-ecosystem: npm
    directory: /
    schedule:
      interval: weekly
    groups:
      types:
        patterns: ['@types/*']
      eslint:
        patterns: ['eslint*', '@typescript-eslint/*']
      production:
        dependency-type: production
        update-types: [patch, minor]
```

**Catch.** Major bumps still get individual PRs by default; that's
correct.

### 28. Test the action you ship

**Why.** A repo that publishes a GitHub Action without a self-test is one
release away from a regression.

**Apply.** Add a workflow that uses your own action against a fixture
repo or its own fixtures:

```yaml
jobs:
  self-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: ./
        with:
          example: input
```

**Catch.** This catches functional regressions, not packaging ones.
Pair with a release workflow that verifies the marketplace tarball.

### 29. Lockfile the action's runtime deps

**Why.** A JavaScript action installs deps at consume-time. If you don't
ship a `dist/` bundle, every consumer pays the install.

**Apply.** Bundle with `esbuild` or `@vercel/ncc`. Commit `dist/`. Add a
CI step that fails the build if `dist/` is out of sync with source.

**Catch.** `dist/` looks ugly in PRs. Mark it as generated in `linguist`.

### 30. Audit the workflows themselves

**Why.** Workflows accrete. Last year's trigger is this year's noise.
Yesterday's macOS runner is today's bill.

**Apply.** Run [`ci-doctor`](https://www.npmjs.com/package/ci-doctor)
on a schedule, or as a PR check:

```yaml
- uses: depmedicdev-byte/ci-doctor@v0.1.0
  with:
    fail-on: error
```

**Catch.** Set `fail-on: warn` for new repos and `error` for established
ones. Pure-info workflows should at least be visible to maintainers
even if not blocking.

---

## Putting it together

A reasonable PR workflow that adopts patterns 1, 3, 4, 8, 14, 21:

```yaml
name: pr
on:
  pull_request:
permissions:
  contents: read
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
jobs:
  setup:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci --prefer-offline --no-audit --progress=false

  lint:
    needs: setup
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci --prefer-offline --no-audit --progress=false
      - run: npm run lint

  types:
    needs: setup
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci --prefer-offline --no-audit --progress=false
      - run: npm run typecheck

  test:
    needs: setup
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20, cache: npm }
      - run: npm ci --prefer-offline --no-audit --progress=false
      - run: npm test
```

That's the floor. The ceiling is patterns 2, 6, 12, 22, 26 layered on
top once the team is ready.

## What you'd do next

1. Run `npx ci-doctor` against your repo. The output names the patterns
   you're missing.
2. Open a single PR titled "ci: adopt cookbook patterns 1, 3, 4". Don't
   merge twenty patterns at once.
3. After two weeks, look at your billing dashboard and your average PR
   completion time. Decide what to adopt next.

---

_Cookbook by depmedic. Latest version at
<https://polar.sh/depmedicdev/gha-cookbook>._
