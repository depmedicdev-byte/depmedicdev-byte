# Cut Your CI Bill

30 patterns for cheaper, faster, less leaky GitHub Actions workflows. Plus
5 paste-ready snippet files.

By the author of [`ci-doctor`](https://github.com/depmedicdev-byte/ci-doctor),
the free workflow auditor.

## What's in the pack

```
COOKBOOK.md            # 30 patterns, fully worked
snippets/
  01-pr-fast-lane.yml  # cancel superseded runs, cache, fast-tier matrix
  02-monorepo-affected-only.yml  # only test packages that changed
  03-cache-everything.yml        # node, pip, gradle, go, docker layers
  04-pin-actions-by-sha.yml      # safe third-party action use
  05-nightly-full-matrix.yml     # full matrix on schedule, lean on PRs
LICENSE-COMMERCIAL.txt
CHANGELOG.md
```

Each snippet is a complete `.yml` workflow you can copy into
`.github/workflows/` and tune to your repo.

## Start here

1. Read `COOKBOOK.md` end to end. ~25 minutes. The patterns are short.
2. Run [`ci-doctor`](https://www.npmjs.com/package/ci-doctor) on your repo
   to see which patterns you're already missing:
   ```bash
   npx ci-doctor
   ```
3. Open a PR that adopts the top 3 patterns by impact. Most teams cut
   30-60% of CI minutes from the first PR alone.

## License

Commercial use license. See `LICENSE-COMMERCIAL.txt`. Single buyer,
unlimited projects, do not redistribute as a separate product.

## Updates

Free updates within v1.x. Latest at
<https://polar.sh/depmedicdev/gha-cookbook>.
