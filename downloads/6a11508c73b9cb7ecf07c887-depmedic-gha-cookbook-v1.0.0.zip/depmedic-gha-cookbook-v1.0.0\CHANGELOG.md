# Changelog

## v1.0.0 - 2026-04-27

Initial release.

- 30 patterns covering cost (10), speed (10), security (5), and
  maintenance (5) for GitHub Actions workflows.
- 5 paste-ready snippet workflows: PR fast lane, monorepo affected-only,
  cache-everything, SHA-pinned actions, nightly full matrix.
- Commercial-use license.
- Companion to the free [`ci-doctor`](https://github.com/depmedicdev-byte/ci-doctor)
  auditor.
