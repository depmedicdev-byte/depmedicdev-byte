GHA Performance Patterns - depmedic - v1.0

Files in this bundle:
- gha-performance-patterns.pdf    Letter PDF, primary read.
- gha-performance-patterns.html   Browser-friendly twin.
- LICENSE.txt                     MIT for the YAML snippets.

Order to apply (cheapest first):
  1, 3, 11, 12                    Free, one-line edits.
  2, 5, 6                         One-time setup (worth the hour).
  7, 8                            Monorepo / Docker-only.
  4, 9, 10                        Case-by-case.

Companion tools (free, MIT):
  npx ci-doctor                   Audit any .github/workflows/*.yml.
  npx gha-budget                  Price a workflow before you push.

Companion product (paid):
  Cut Your CI Bill - 30 cost patterns + 5 templates, $19.
  https://depmedicdev-byte.github.io/

Issues / refunds: depmedic.dev@gmail.com
