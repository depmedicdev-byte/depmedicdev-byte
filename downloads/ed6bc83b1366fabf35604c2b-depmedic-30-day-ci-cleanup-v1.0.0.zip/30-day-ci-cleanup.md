# Day 0 - The premise

You picked this up because someone is paying for your CI minutes, and the
number is bigger than it should be. Maybe by 2x. Maybe by 10x. The reason
is rarely a single villain - it is 30 small leaks compounding.

This book is a 30-day program. **One pattern per day**, ~5 minutes of reading,
~15 minutes of YAML edits, then push and watch the bill move. By Day 30 the
typical reader has cut their GitHub Actions monthly bill by 30-70% and
shipped a more reliable pipeline along the way.

## How to use this

- **Mon-Fri only.** Take weekends off. Six weeks calendar time, 30 working days.
- **One pattern at a time.** Resist the urge to ship 8 patterns in one PR.
  When something breaks, you want to know which one to revert.
- **Each day has the same shape:** Why (the failure mode), Apply (the
  smallest YAML change that fixes it), Catch (the gotcha to look out for),
  Today's homework (a 5-line checklist you can paste into your PR description).

## Companion tools (free)

- `npx ci-doctor` - audits your workflows against 14 cost/security/reliability
  rules. Run it on Day 0 to get your baseline score.
- `npx gha-budget` - estimates the dollar cost of a workflow before you push.
  Run it on Day 30 to measure the delta.
- [depmedicdev-byte.github.io/scan.html](https://depmedicdev-byte.github.io/scan.html) -
  same scan in the browser, no install. Good for sharing reports with PMs.
- [depmedicdev-byte.github.io/leaderboard.html](https://depmedicdev-byte.github.io/leaderboard.html) -
  see how 40 popular OSS projects score on the same 14 rules. Calibrates
  expectations.

## Day 0 homework

Open a terminal in your main repo and run:

```sh
npx ci-doctor
npx gha-budget
```

Save the output. That is your before snapshot. We will diff against it on
Day 30.

# Day 1 - Cancel superseded runs with concurrency

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 2 - Use `ubuntu-latest` unless you genuinely need macOS or Windows

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 3 - Cache language tooling

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 4 - Set `timeout-minutes` on every job

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 5 - `paths:` filters on heavy workflows

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 6 - Trim the matrix on PRs, full matrix on schedule

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 7 - Short artifact retention

> Week 1: The 7 leaks that account for half your bill



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 8 - Skip duplicate runs on push + pull_request

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 9 - Replace expensive `act-runner` startup with `setup-buildx-action`

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 10 - Cache Docker layers with the GitHub Actions cache backend

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 11 - Parallelize tests with sharding

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 12 - Hoist common setup into a composite action

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 13 - `npm ci --prefer-offline --no-audit --progress=false`

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 14 - Run lints, types, and tests in parallel jobs

> Week 2: Caching, matrices, and the cost of "yes always"



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 15 - Use `actions/cache` for ad-hoc directories

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 16 - Parallel matrix without job dependencies

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 17 - Smaller checkout

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 18 - Skip the GitHub Pages step on PRs

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 19 - Use `pnpm` if your team can swap

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 20 - Skip CI on draft PRs

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 21 - Top-level `permissions: contents: read`

> Week 3: Reliability traps that look like cost wins



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 22 - Pin third-party actions to a SHA, not a tag

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 23 - Don't expose secrets to actions you can't audit

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 24 - `pull_request_target` is dangerous; treat it as such

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 25 - Use `OIDC` for cloud creds, not long-lived secrets

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 26 - Reusable workflows for repeated shapes

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 27 - Dependabot grouped updates

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 28 - Test the action you ship

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 29 - Lockfile the action's runtime deps

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# Day 30 - Audit the workflows themselves

> Week 4: Security hygiene and the 30-day audit



**Today's homework.**

- Find every workflow file in `.github/workflows/` that this pattern applies to.
- Open one PR per pattern, not one PR per repo.
- Run `npx ci-doctor --fix` after the change to verify the audit clears.
- Push, merge, watch the next CI run.


# After Day 30 - what next

You shipped 30 small PRs. You have a baseline (Day 0) and a delta (today).
Two follow-ups will keep the bill from creeping back up:

## 1. Wire ci-doctor into CI itself

Add this to a new workflow `.github/workflows/ci-doctor.yml`:

```yaml
name: ci-doctor
on:
  pull_request:
    paths:
      - '.github/workflows/**'
permissions:
  contents: read
jobs:
  audit:
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - run: npx -y ci-doctor --fail-on warn
```

Now every PR that touches a workflow gets audited. Regressions stop at the
gate.

## 2. Track the bill weekly

Open the GitHub Actions usage page once a week. Or - if you graduated to
the depmedic Pro license - use the org policy report which gives you per-repo
breakdowns and trend lines.

## 3. Pick the right runner provider

If you are still paying GitHub-hosted prices on Linux at >50,000 minutes per
month, switch. The cheapest one-line change is a third-party runner provider
(BuildJet, Namespace, Ubicloud). The comparison page at
[depmedicdev-byte.github.io/runners.html](https://depmedicdev-byte.github.io/runners.html)
covers six of them with current pricing.

## 4. Ask AI when you get stuck

Paste any workflow into [/ask.html](https://depmedicdev-byte.github.io/ask.html)
and ask "explain", "fix", "estimate cost", or "convert from CircleCI". Free
5 calls per day. The license key for unlimited usage is included with the
depmedic Pro subscription ($5/mo).

## 5. Pass it on

If this saved your team a meaningful number of dollars, the most useful
thing you can do is link to a chapter in your own engineering blog or
internal wiki. Search engines weight inbound dev links heavily; one
referral helps the next team find this faster.

---

**Where to send feedback.** depmedic.dev@gmail.com. Bug reports for the
free CLIs go to https://github.com/depmedicdev-byte. Errata for this book
go to either.

**License.** This ebook is licensed for the buyer's personal and team use.
Sharing PDFs across an org of <50 is fine. Republishing the text on a
public site is not.

Thanks for reading.
