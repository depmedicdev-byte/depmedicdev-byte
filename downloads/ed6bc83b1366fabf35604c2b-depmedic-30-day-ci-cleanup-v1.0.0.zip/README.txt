30-Day CI Cleanup
by depmedic

Files in this bundle:
- 30-day-ci-cleanup.pdf  (Letter, primary format)
- 30-day-ci-cleanup.html (single-file HTML, browser-friendly)
- 30-day-ci-cleanup.md   (raw markdown source)
- LICENSE.txt            (license terms)

License: see LICENSE.txt. Personal and team use OK; do not republish on
a public site without permission.

Updates within v1.x are free; emailed when they ship.
Errata / questions: depmedic.dev@gmail.com