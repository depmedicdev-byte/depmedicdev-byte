GitHub Actions Cheat Sheet v1.0 - depmedic

Files:
- gha-cheatsheet.pdf  (print-ready Letter landscape, 2 pages, double-sided)
- gha-cheatsheet.html (browser-friendly twin)
- LICENSE.txt
