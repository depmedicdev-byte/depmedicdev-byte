# Self-Hosted Runner Setup Pack v1.0.0

Stand up GitHub Actions self-hosted runners on AWS Spot or Hetzner Cloud.
Terraform + Ansible + a breakeven calculator so you don't waste hours
on a "savings" that costs more than GitHub-hosted did.

## What's in the pack

- `terraform/aws-spot/` - autoscaling Spot fleet (1-N c7i.xlarge), OIDC,
  registration via PAT in SSM, ASG with mixed-instance fallback.
- `terraform/hetzner/` - 2-N CPX21 (4 vCPU AMD) Hetzner Cloud servers,
  cheaper than AWS Spot for predictable load.
- `ansible/install-runner.yml` - drop-in playbook for any existing
  Ubuntu 22.04 hosts (bare metal, on-prem, other clouds).
- `tools/cost-calc.html` - open in a browser; tells you whether AWS Spot
  or Hetzner makes economic sense at your usage, including ops overhead.
- `docs/RUNBOOK.md` - decision tree, deploy steps per option,
  operational alerts, common failure modes.

## Setup time

- AWS Spot: ~30 min from `terraform init` to first job picked up.
- Hetzner: ~20 min.
- Ansible on an existing host: ~5 min per host.

## When NOT to self-host

- You spend less than ~$200/mo on GitHub-hosted right now (your engineering
  overhead will exceed the savings).
- You don't have someone who can patch / monitor the fleet.
- Your jobs are bursty - GitHub-hosted's per-second billing wins for that.

In any of those cases, the third-party runner alternatives at
depmedicdev-byte.github.io/runners.html are usually the better answer
(50-70% cheaper than GitHub-hosted, zero ops).

## Pair with the free CLIs

```
npx ci-doctor    # the expensive-runner rule will tell you what to migrate
npx gha-budget   # baseline before-and-after savings
```

## License

See LICENSE.txt - single org, free updates within v1.x.
