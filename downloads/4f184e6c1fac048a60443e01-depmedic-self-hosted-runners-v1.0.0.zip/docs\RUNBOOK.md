# Self-hosted runner runbook

## Decision: Spot, always-on, or third-party?

| Pattern               | Best for                                                         |
| --------------------- | ---------------------------------------------------------------- |
| AWS Spot autoscaling  | Workloads that need AWS-private resources, ~$0.085/hr per c7i.xl |
| Hetzner always-on     | Predictable load, EU OK, $8/mo per CPX21                         |
| Third-party (BuildJet, Namespace, RunsOn, ...) | Want zero ops; see /runners.html        |

Run `tools/cost-calc.html` in a browser, plug in your numbers, decide.

## AWS Spot deploy (~30 min)

1. `cd terraform/aws-spot`
2. Create `terraform.tfvars`:
   ```hcl
   github_owner = "your-org"
   github_repo  = "your-org/your-repo"
   vpc_id       = "vpc-..."
   subnet_ids   = ["subnet-...", "subnet-..."]
   ami_id       = "ami-..."   # Ubuntu 22.04 in your region
   max_size     = 10
   ```
3. `terraform init && terraform apply`
4. In the GitHub repo or org, create a fine-scoped PAT
   (`actions:write`, `administration:write`) and store it
   in AWS Systems Manager Parameter Store as `/gha-runner/REG_PAT`.
   Update user-data.sh.tftpl to fetch it via `aws ssm get-parameter`.
5. Set `desired_capacity` to a small number (e.g., 1) to test.
   Verify the runner appears under repo Settings > Actions > Runners.

## Hetzner deploy (~20 min)

1. `cd terraform/hetzner`
2. Set `HCLOUD_TOKEN` env var.
3. Create `terraform.tfvars`:
   ```hcl
   github_repo  = "your-org/your-repo"
   runner_count = 2
   server_type  = "cpx21"
   location     = "nbg1"
   ssh_keys     = ["your-ssh-key-id"]
   ```
4. `terraform init && terraform apply`
5. Pre-set `REG_PAT` env in cloud-init via Hetzner secrets, or hardcode
   for a quick test (NOT for production - rotate immediately).

## Ansible install (existing hosts)

```
export GITHUB_PAT=ghp_xxx
ansible-playbook -i ansible/hosts.ini ansible/install-runner.yml -e github_repo=org/repo
```

## Operational

- **Patching**: Runners are ephemeral on AWS Spot (Spot termination
  automatically rotates them); on Hetzner, run unattended-upgrades or
  re-image weekly.
- **Logs**: Runner logs at `/opt/runner/_diag`. Ship to CloudWatch /
  Loki with a sidecar.
- **Alerts**: Alarm if no runner is online for 5+ minutes during business
  hours.
- **Scaling**: AWS ASG scales 0-10 by default. Tune `max_size` to your
  budget. Hetzner is fixed-size; bump `runner_count` and re-apply.

## Common failure modes

- **PAT expires**: regenerate, update SSM/secret, re-deploy.
- **Spot capacity unavailable**: ASG auto-rotates. If persistent, add
  more instance types in `instance_types_override`.
- **Runner labels missing**: jobs that target `self-hosted,linux,xyz`
  silently queue forever. Check labels match.
- **Workflow exhausts disk**: default Ubuntu AMI is 8GB; bump
  block_device_mappings in launch_template if your builds need more.
