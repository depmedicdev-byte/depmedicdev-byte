variable "aws_region"      { default = "us-east-1" }
variable "environment"     { default = "prod" }
variable "github_owner"    { description = "GitHub org or user" }
variable "github_repo"     { description = "owner/repo" }
variable "runner_group"    { default = "default" }
variable "runner_labels"   { default = ["self-hosted", "linux", "x64", "spot"] }
variable "runner_version"  { default = "2.317.0" }
variable "vpc_id"          { description = "VPC the runners run in" }
variable "subnet_ids"      { type = list(string) }
variable "ami_id"          { description = "Ubuntu 22.04 LTS AMI in your region" }
variable "instance_type"   { default = "c7i.xlarge" }
variable "instance_types_override" {
  type    = list(string)
  default = ["c7i.xlarge", "c7a.xlarge", "c6i.xlarge", "m7i.xlarge"]
}
variable "max_spot_price_per_hour" { default = "0.10" }
variable "desired_capacity" { default = 0 }
variable "min_size"         { default = 0 }
variable "max_size"         { default = 10 }
