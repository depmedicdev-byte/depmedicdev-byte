# Hetzner Cloud cheap runners. Often 50-70% cheaper than AWS Spot
# for similar throughput. Pay attention to data egress (Hetzner is generous).

terraform {
  required_version = ">= 1.6"
  required_providers {
    hcloud = { source = "hetznercloud/hcloud", version = "~> 1.46" }
  }
}

provider "hcloud" { token = var.hcloud_token }

resource "hcloud_server" "runner" {
  count       = var.runner_count
  name        = "${var.name_prefix}-${count.index}"
  image       = "ubuntu-22.04"
  server_type = var.server_type   # cpx21 (4 vCPU AMD, ~$8/mo), cpx31 (4 vCPU AMD ~$15/mo)
  location    = var.location      # nbg1, fsn1, hel1, ash, hil
  ssh_keys    = var.ssh_keys
  user_data = templatefile("${path.module}/user-data.sh.tftpl", {
    repo           = var.github_repo
    runner_version = var.runner_version
    labels         = join(",", var.runner_labels)
  })
  labels = { managed-by = "terraform", purpose = "gha-runner" }
}
