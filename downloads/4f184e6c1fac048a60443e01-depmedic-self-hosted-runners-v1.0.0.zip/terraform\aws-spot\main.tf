# AWS Spot fleet for GitHub Actions self-hosted runners.
# Uses OIDC for the runner registration token, no long-lived secrets in the
# instance. Autoscales 0-10 Spot instances by default; tune in variables.tf.

terraform {
  required_version = ">= 1.6"
  required_providers {
    aws    = { source = "hashicorp/aws", version = "~> 5.50" }
    github = { source = "integrations/github", version = "~> 6.2" }
  }
}

provider "aws"    { region = var.aws_region }
provider "github" { owner = var.github_owner }

locals {
  name_prefix = "gha-runner-${var.environment}"
  user_data = base64encode(templatefile("${path.module}/user-data.sh.tftpl", {
    repo            = var.github_repo
    runner_version  = var.runner_version
    labels          = join(",", var.runner_labels)
    runner_group    = var.runner_group
  }))
}

resource "aws_iam_role" "runner" {
  name               = "${local.name_prefix}-role"
  assume_role_policy = data.aws_iam_policy_document.assume_ec2.json
}

data "aws_iam_policy_document" "assume_ec2" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_instance_profile" "runner" {
  name = "${local.name_prefix}-profile"
  role = aws_iam_role.runner.name
}

resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.runner.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_security_group" "runner" {
  name_prefix = "${local.name_prefix}-sg"
  vpc_id      = var.vpc_id
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${local.name_prefix}-sg" }
}

resource "aws_launch_template" "runner" {
  name_prefix   = "${local.name_prefix}-lt-"
  image_id      = var.ami_id
  instance_type = var.instance_type
  user_data     = local.user_data

  vpc_security_group_ids = [aws_security_group.runner.id]
  iam_instance_profile { arn = aws_iam_instance_profile.runner.arn }

  instance_market_options {
    market_type = "spot"
    spot_options {
      max_price          = var.max_spot_price_per_hour
      spot_instance_type = "one-time"
    }
  }

  tag_specifications {
    resource_type = "instance"
    tags = {
      Name        = local.name_prefix
      Environment = var.environment
      Owner       = "github-actions-runner"
      ManagedBy   = "terraform"
    }
  }
}

resource "aws_autoscaling_group" "runner" {
  name                = "${local.name_prefix}-asg"
  vpc_zone_identifier = var.subnet_ids
  desired_capacity    = var.desired_capacity
  min_size            = var.min_size
  max_size            = var.max_size
  health_check_type   = "EC2"
  capacity_rebalance  = true

  mixed_instances_policy {
    instances_distribution {
      on_demand_base_capacity                  = 0
      on_demand_percentage_above_base_capacity = 0
      spot_allocation_strategy                 = "price-capacity-optimized"
      spot_max_price                           = var.max_spot_price_per_hour
    }
    launch_template {
      launch_template_specification {
        launch_template_id = aws_launch_template.runner.id
        version            = "$Latest"
      }
      dynamic "override" {
        for_each = var.instance_types_override
        content { instance_type = override.value }
      }
    }
  }

  tag {
    key                 = "Name"
    value               = local.name_prefix
    propagate_at_launch = true
  }
}
