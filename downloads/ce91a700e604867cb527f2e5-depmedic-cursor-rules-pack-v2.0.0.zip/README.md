# Cursor Rules Pack v2 (depmedic)

A drop-in `.cursor/rules/` directory for senior-grade Cursor sessions.

Versions covered:
- React 19
- Next.js 15 (App Router, async APIs, PPR, caching defaults)
- Astro (islands, content collections, hybrid output)
- Bun (runtime + package manager + bundler)
- Hono (HTTP framework for Workers / Bun / Node)
- Plus framework-agnostic baselines: senior defaults, error handling,
  API design, testing, git/PR, and CI hygiene gates.

## Install

Drop the `.cursor/rules/` directory into the root of any repo.

That's it. Cursor picks them up automatically.

## What each rule does

| File                              | Always-on | Triggered by               |
| --------------------------------- | --------- | -------------------------- |
| 00-senior-defaults.mdc            | yes       | -                          |
| 10-react-19.mdc                   | no        | tsx, jsx, src files        |
| 11-nextjs-15.mdc                  | no        | app/, src/app/, next.config|
| 12-astro.mdc                      | no        | .astro, src/, astro.config |
| 13-bun.mdc                        | no        | ts/js, bunfig, package.json|
| 14-hono.mdc                       | no        | ts/tsx, src/api            |
| 20-cursor-best-practices.mdc      | yes       | -                          |
| 21-error-handling.mdc             | yes       | -                          |
| 22-api-design.mdc                 | no        | route handlers             |
| 23-testing.mdc                    | yes       | -                          |
| 24-git-pr.mdc                     | yes       | -                          |
| 30-cidoctor-and-budget.mdc        | no        | .github/workflows          |

## License

See LICENSE.txt. Single-org, internal use. Free updates within v2.x.

## Free CLIs that pair well

- `npx ci-doctor` - audit GitHub Actions workflows.
- `npx gha-budget` - price a workflow before you push.
- `npx pin-actions` - rewrite uses: tags to commit SHAs.
- `npx depmedic` - triage `npm audit` by severity.
- `npx cursor-rules-init` - quick-start `.cursor/rules/` for new repos.

## Get the underlying playbooks

If you find these rules useful, you'll like the writeups they distill:

- 30-Day CI Cleanup ebook ($19, 30 daily lessons)
- Cut Your CI Bill cookbook ($19, 30 patterns)
- Hardened Workflows Pack ($9, 5 production-ready YAML files)
- Everything Bundle ($59, all paid playbooks past + future 12 mo)

depmedicdev-byte.github.io
