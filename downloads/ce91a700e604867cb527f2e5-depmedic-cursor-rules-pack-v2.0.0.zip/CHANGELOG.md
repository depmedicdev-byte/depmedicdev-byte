# Changelog - Cursor Rules Pack

## v2.0.0 - 2026-04-28
- New: Next.js 15 rules (async APIs, caching default flip, PPR, server actions).
- New: React 19 rules (compiler memoization, use(), refs as props, server actions).
- New: Astro rules (islands, content collections, hybrid output, adapters).
- New: Bun rules (when to pick, native APIs, test runner, what to avoid).
- New: Hono rules (RPC type sharing, zValidator, Workers idioms).
- New: 22-api-design baseline (URL conventions, idempotency, pagination, errors).
- New: 30-cidoctor-and-budget gate (auto-runs the right CLI on workflow edits).
- Refresh: senior-defaults, error-handling, testing, git/PR baselines.
- Per-rule `globs:` so framework rules only fire when they should.

## v1.x
- Original `.cursorrules` flat file. Superseded by the multi-file
  `.cursor/rules/*.mdc` format.
