# Monorepo CI Workflows Pack v1.0.0

Five drop-in GitHub Actions workflows for monorepos. Pick the one that
matches your tooling, drop into .github/workflows/, fill in 2-3
secrets/vars, and you're done.

## Files

| File                            | Use if                                                      |
| ------------------------------- | ----------------------------------------------------------- |
| turbo-affected.yml              | You use Turborepo (turbo run --filter)                      |
| nx-affected.yml                 | You use Nx (nx affected with last-successful base)          |
| lerna-changed.yml               | You use Lerna 8+ (lerna run --since)                        |
| pnpm-workspaces-affected.yml    | You use pnpm workspaces with no extra tool                  |
| cache-warm-shared.yml           | You want a nightly remote-cache warm job (any of the above) |

## What's already done for you

Every workflow includes:
- `concurrency:` block with PR-cancel-in-progress (saves ~30-50% of PR minutes)
- `timeout-minutes:` per job (no 6-hour runaway)
- `permissions: contents: read` baseline + per-job escalation only when needed
- All `uses:` pinned to commit SHAs (supply-chain hygiene)
- Language-toolchain caches (`cache: pnpm` / `cache: npm`)
- Affected-only run on PRs, full run on main pushes (keeps PRs fast)
- `fetch-depth: 0` only where the affected detection actually needs it

## Setup

### Required secrets / vars per workflow

**turbo-affected.yml:**
- `secrets.TURBO_TOKEN`     - your remote-cache auth token
- `vars.TURBO_TEAM`         - your turbo team slug
- `secrets.TURBO_SIGNATURE_KEY` - optional; signs cache artifacts

**nx-affected.yml:**
- (none required for vanilla Nx)
- For DTE: `secrets.NX_CLOUD_AUTH_TOKEN` and add the start-ci-run line

**lerna-changed.yml:**
- (none required)

**pnpm-workspaces-affected.yml:**
- (none required)

**cache-warm-shared.yml:**
- `vars.AWS_CACHE_ROLE_ARN` - role to assume via OIDC
- `secrets.TURBO_TOKEN`     - if you use turbo

## Why this saves money

- "Affected only" + concurrency cancel together cut PR runtime 30-60% on
  the typical monorepo of 5+ packages.
- The shared cache-warm job ensures cold caches don't bite when a PR
  starts before another finishes.
- All workflows pinned to SHAs so a compromised tag never silently runs
  in your CI (see https://snyk.io/blog/popular-actions-supply-chain).

## Pair with the free CLIs

```
npx ci-doctor    # audit any of these workflows against 14 rules
npx gha-budget   # see the projected cost per PR before you push
npx pin-actions  # rewrite floating tags to SHAs (already done here)
```

## License

See LICENSE.txt - single org / single repo class. Free updates within v1.x.
