# Why each YAML choice

## fetch-depth: 0
We need full git history because the affected-package detection (turbo
`...[ref]`, nx-set-shas, lerna --since, pnpm `...[base...HEAD]`) all
diff against the merge base. Without history, the diff base is missing
and either the run errors out or every package is treated as affected
(defeating the optimization).

A common alternative is `fetch-depth: 50` which is cheaper for huge
histories but breaks when the PR is older than 50 commits behind main.
Setting `filter: tree:0` (Nx file) is a partial-clone trick - we get
the history graph without the file blobs, then check out blobs lazily.

## concurrency block
`group: ${{ github.workflow }}-${{ github.ref }}` per branch.
`cancel-in-progress: ${{ github.event_name == 'pull_request' }}` -
cancel old PR runs but never main pushes. Cancelling a main push leaves
the cache half-warmed and breaks the cache-warm job.

## permissions baseline
`contents: read` is the GitHub-recommended default. Per-job escalation
to `id-token: write` is for OIDC (AWS / Cloudflare R2 / Vercel /
publishing flows). Never blanket-grant `write-all`.

## SHA-pinned uses
GitHub Actions tags can be force-moved by their owner; SHAs cannot. After
the tj-actions/changed-files supply-chain incident in 2023, every
production CI should pin to SHAs for any third-party action. The trailing
comment shows the human-readable version for upgrade hygiene.

## Per-job timeouts
GitHub's default is 360 minutes (6 hours). A hung step on a self-hosted
runner can otherwise eat a workday of paid runner time before GitHub
kills it. We set 25-30 minutes for monorepo CI which fits the 95th
percentile of real-world projects.

## Why turbo / nx prefer remote caches
Without remote cache, every CI cold-start does a full build of every
affected package's dependencies. The remote cache means a CI worker
downloading a precomputed build artifact instead. On a typical monorepo
this is a 5x speed difference for build steps and a 2-3x difference
overall.

## When NOT to use this pack
- You have one package and no monorepo. Use the Hardened Workflows Pack
  instead - simpler templates for single-package repos.
- Your monorepo lives on GitLab. The patterns translate, but the YAML
  syntax is different - see the GitLab port (in development) at
  depmedicdev-byte.github.io.
- You're on Bazel - that's a different cost model entirely; this pack
  doesn't help.
