# USAGE

## Quick start

Place a single `.cursorrules` file at the root of your project. Cursor picks
it up automatically. Restart the chat after changing it.

## Recommended starter blends

### TypeScript + React + Next.js app

```
cat rules/00-core.cursorrules \
    rules/01-typescript-strict.cursorrules \
    rules/02-react-modern.cursorrules \
    rules/03-nextjs-app-router.cursorrules \
    rules/11-error-handling.cursorrules \
    rules/12-security-defaults.cursorrules \
    rules/14-accessibility.cursorrules \
    rules/08-test-vitest.cursorrules \
  > .cursorrules
```

### Node API service

```
cat rules/00-core.cursorrules \
    rules/01-typescript-strict.cursorrules \
    rules/05-node-server.cursorrules \
    rules/06-rest-api.cursorrules \
    rules/07-postgres-sql.cursorrules \
    rules/11-error-handling.cursorrules \
    rules/12-security-defaults.cursorrules \
    rules/09-test-jest.cursorrules \
  > .cursorrules
```

### Python CLI / data tool

```
cat rules/00-core.cursorrules \
    rules/04-python-clean.cursorrules \
    rules/10-test-pytest.cursorrules \
    rules/11-error-handling.cursorrules \
    rules/19-shell-scripts.cursorrules \
  > .cursorrules
```

### Monorepo platform team

```
cat rules/00-core.cursorrules \
    rules/22-monorepo.cursorrules \
    rules/20-docker.cursorrules \
    rules/21-github-actions.cursorrules \
    rules/12-security-defaults.cursorrules \
  > .cursorrules
```

## Mode-switching rules

`15-code-review-mode.cursorrules`, `16-debug-methodology.cursorrules`, and
`17-refactor-safely.cursorrules` are designed to be swapped in temporarily
when the task changes. Keep one project `.cursorrules`, and copy the
mode rule into a chat-scoped rule via Cursor's rule UI when needed.

## When rules conflict

Later rules in the concatenated file override earlier ones. Put `00-core` first
and put the most specific stack rule last.

## Updating

Watch the changelog at <https://polar.sh/depmedicdev/cursor-rules> for
new rules and tweaks. Every buyer gets free updates to the next minor.

## Reporting issues

Open an issue at <https://github.com/depmedicdev-byte/depmedic/issues>.
Include the rule filename and an example of the failed behavior.
