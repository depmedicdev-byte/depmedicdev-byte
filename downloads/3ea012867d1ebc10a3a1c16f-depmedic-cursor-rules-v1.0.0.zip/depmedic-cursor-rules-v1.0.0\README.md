# depmedic Senior Dev Cursor Rules

A bundle of 24 hand-tuned `.cursorrules` files plus 3 system prompts that
make Cursor act like a senior dev with hard taste and tight token discipline.

These rules are what I use day to day on real codebases. Drop them into your
project, restart Cursor, and the assistant stops over-explaining, stops
rewriting whole files when one block changed, stops sprinkling em-dashes,
and starts shipping changes you can land.

## What's in the pack

```
rules/
  00-core.cursorrules                   # Voice, taste, defaults
  01-typescript-strict.cursorrules
  02-react-modern.cursorrules
  03-nextjs-app-router.cursorrules
  04-python-clean.cursorrules
  05-node-server.cursorrules
  06-rest-api.cursorrules
  07-postgres-sql.cursorrules
  08-test-vitest.cursorrules
  09-test-jest.cursorrules
  10-test-pytest.cursorrules
  11-error-handling.cursorrules
  12-security-defaults.cursorrules
  13-performance.cursorrules
  14-accessibility.cursorrules
  15-code-review-mode.cursorrules
  16-debug-methodology.cursorrules
  17-refactor-safely.cursorrules
  18-git-commits.cursorrules
  19-shell-scripts.cursorrules
  20-docker.cursorrules
  21-github-actions.cursorrules
  22-monorepo.cursorrules
  23-zero-output-mode.cursorrules
prompts/
  senior-dev-system.md
  code-review.md
  bug-investigation.md
```

Mix and match. Most teams concatenate `00-core.cursorrules` plus 3-5 stack
overlays into a single project `.cursorrules` file. Examples in `USAGE.md`.

## Why this exists

Default Cursor output is fine for greenfield. On a real codebase it tends to:

- Apologize.
- Restate context.
- Rewrite working code as a side effect of a small ask.
- Use marketing words.
- Prefer breadth over depth.

These rules are calibrated against those failure modes.

## Install

1. Unzip into your project root.
2. Concatenate the rules you want into a single `.cursorrules` file at the
   project root. See `USAGE.md` for the recommended starter blends.
3. Restart Cursor (or start a new chat). The model picks up new rules at the
   next session boundary.

## License

Commercial use license, single buyer, unlimited projects. See
`LICENSE-COMMERCIAL.txt`. Do not redistribute the pack as a standalone
product.

## Updates

Rules iterate as Cursor and the underlying models change. Buyers get free
updates to the next minor version. Latest pack at
<https://polar.sh/depmedicdev/cursor-rules>.

## Companion

- [`depmedic`](https://www.npmjs.com/package/depmedic) - npm vulnerability triage CLI.
- [`ci-doctor`](https://www.npmjs.com/package/ci-doctor) - GitHub Actions auditor.

Both free, MIT, by the same author.
