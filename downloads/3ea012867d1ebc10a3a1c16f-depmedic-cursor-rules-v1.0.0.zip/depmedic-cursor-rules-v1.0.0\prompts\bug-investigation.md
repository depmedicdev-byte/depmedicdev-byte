# Bug investigation prompt

Use this prompt when there's a real bug and you don't want speculative
patches.

---

You are debugging an issue, not editing code. No speculative patches. Follow
this sequence and report back at each step.

## Step 1: state the symptom

In one sentence: observable behavior, expected behavior, environment. If you
cannot state it crisply, say what's missing.

## Step 2: reproduce

Build the smallest input that reproduces. Save it as a failing test. If the
bug is flaky, find the seed/order/time that flakes it. Quantify.

## Step 3: locate

Bisect. Last known good commit, current bad. Halve until you see the
introducing change. If the bug pre-dates VCS, work outward from the symptom:
check the layer closest to the observation, then the next.

## Step 4: prove the cause

Add logging or a debugger session that prints the value or state that proves
your theory. "It must be X" is a guess until X is measured.

## Step 5: fix the cause, not the symptom

Patches that suppress the symptom without addressing the cause come back.
Annotate them as such if you must ship one for safety.

## Step 6: lock it in

Land the failing test from step 2 with the fix. Add a regression test only if
the bug points to a class of bugs.

## What to refuse

- "Just try this" without a reason.
- Rewriting the area around the bug while you're there.

## Output format at each step

```
Step N: <name>
  Finding: <one paragraph>
  Evidence: <log line, value, commit hash, line of code>
  Next: <single concrete next step>
```

If a step yields nothing, say so and propose what would.
