# Changelog

## v1.0.0 - 2026-04-27

Initial release.

- 24 `.cursorrules` files covering core voice, language stacks (TypeScript,
  React, Next.js App Router, Python, Node.js server-side), API design (REST,
  Postgres + SQL), testing (Vitest, Jest, pytest), error handling, security
  defaults, performance, accessibility, code-review mode, debug methodology,
  refactoring, git commits, shell scripts, Docker, GitHub Actions, monorepos,
  and a zero-output power-user mode.
- 3 system prompts: senior dev, code review, bug investigation.
- USAGE.md with starter blends per stack.
- Commercial-use license.
