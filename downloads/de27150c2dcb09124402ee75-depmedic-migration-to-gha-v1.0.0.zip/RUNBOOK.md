# Migration to GitHub Actions - Runbook

## Phases (target: 1 small repo per day, week 1; 2-3 repos/week after)

### Phase 0: pre-migration audit (1 hr/repo)
- List every Jenkins/Travis/Circle build job and its purpose.
- For each job, note: trigger, runtime budget, dependencies, secrets,
  artifacts, deploy target.
- Categorize: **must migrate** (used in last 90 days), **archive**
  (not run in 90+ days), **delete** (replaced by something else already).

### Phase 1: green CI on a branch (2-4 hr/repo)
- Convert the most-used job first - usually 'test'.
- Use the per-tool MAPPING.md tables in this pack.
- For Travis: `tools/convert-travis.mjs .travis.yml` produces a starter.
- Push the new workflow to a feature branch. Iterate until green on at
  least 3 PRs (different file types).

### Phase 2: feature parity (2-6 hr/repo)
- Migrate the next-most-used jobs (build, lint, security scan).
- Migrate scheduled jobs (`on.schedule:` cron).
- Migrate deploy jobs LAST. Use OIDC, never long-lived keys (see
  Security-First pack).

### Phase 3: cutover + decommission (1 hr/repo)
- Set the old CI to read-only or disable it (don't delete the config yet).
- Document the cutover date in the repo README.
- Wait one week with both CIs side-by-side; compare output.
- Delete the old config.

### Phase 4: cleanup (1 hr/repo)
- Remove deprecated tokens / SSH keys from the old CI.
- Audit GitHub Actions usage at .github/settings -> Actions usage.
- Run `npx ci-doctor` and `npx gha-budget` to baseline.

## Common migration risks

- **Secrets in the wrong place**. Old CI had org-level secrets you forgot.
  Search the old config for every token reference before cutover.
- **Cron schedule mismatch**. Travis cron uses Travis's tz; GHA cron is UTC.
  Convert and document the offset.
- **Test report format**. Old CI may have been parsing test output to
  produce annotations. GHA needs an explicit reporter action.
- **Artifact paths**. Default retention differs (Travis 0d, Circle 30d,
  GHA 90d). Set `retention-days:` on every upload.
- **Self-hosted agent labels**. Don't migrate self-hosted agents on day
  one - run on GitHub-hosted first, validate, then migrate the agent
  fleet separately.
- **Branch protection rules**. Old CI was a required check by name.
  Re-add the new GHA job names to branch protection or merges break.

## What this pack DOES NOT cover
- Bitbucket Pipelines -> GHA (similar to Travis; convert-travis.mjs
  is a useful starting point).
- Azure Pipelines -> GHA (different conceptual model around stages and
  templates; rewrite is usually faster than translation).
- Bamboo -> GHA (rare in 2026; reach out via depmedic.dev@gmail.com if
  you need help).

## Pair with the free CLIs

```
npx ci-doctor              # audit the migrated workflow
npx gha-budget             # project the new monthly cost
npx pin-actions            # pin all uses: tags to SHAs
```
