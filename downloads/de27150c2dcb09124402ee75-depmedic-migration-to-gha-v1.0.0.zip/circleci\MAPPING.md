# CircleCI -> GitHub Actions mapping

| CircleCI                                | GitHub Actions                                            |
| --------------------------------------- | --------------------------------------------------------- |
| `executor:` (docker, machine)         | `runs-on:` (ubuntu-latest, etc.) + `container:` if needed |
| `orbs:`                               | Reusable workflows (`uses: ./.github/workflows/x.yml`) or composite actions |
| `jobs:` + `workflows.<name>.jobs`   | `jobs:` (the workflow IS the workflow)                  |
| `requires: [a, b]`                    | `needs: [a, b]`                                         |
| `filters.branches.only`               | `on.push.branches` or `if: github.ref == ...`         |
| `filters.tags.only: /^v.*/`           | `on.push.tags: ['v*']` + `if: startsWith(github.ref, 'refs/tags/v')` |
| `store_artifacts`                     | `actions/upload-artifact@v4`                            |
| `store_test_results`                  | `actions/upload-artifact@v4` + a Test Reporter action   |
| `save_cache` / `restore_cache`      | `actions/cache@v4` (or just `cache: npm` on setup-node) |
| `setup_remote_docker`                 | `docker/setup-buildx-action`                            |
| `run:` (with `name:`)               | `- name: x` + `run: ...`                              |
| Approvals (`type: approval`)          | `environment:` with required reviewers                  |
| `when: manual`                        | `workflow_dispatch:` event                              |
| `<< pipeline.git.tag >>`              | `github.ref_name` (only when refs/tags/...)             |
| `<< pipeline.parameters.x >>`         | `inputs.x` (workflow_dispatch / workflow_call)          |
| `context:` (org-level secrets)        | Org-level GitHub Actions secrets / vars                   |
| `resource_class: large`               | `runs-on: ubuntu-latest-4-cores` (or alt-runners)       |
| `parallelism: 4`                      | Matrix split + `actions/test-splitter` style technique  |

## Gotchas
- CircleCI's `workflows` graph maps 1:1 to GHA `jobs:` with `needs:`.
  Don't try to recreate `workflows` as a separate concept.
- `config.yml` references like `<< pipeline.git.tag >>` use a different
  templating language. Replace with GHA contexts (github.*, vars.*, etc.).
- CircleCI's "approval" jobs become `environment:` with required reviewers
  in GHA. The UX is similar but lives in repo settings.
- `setup_remote_docker` is automatic on GHA Linux runners - the docker
  daemon is always there.
