# Migration to GitHub Actions Pack v1.0.0

Move CI from Travis CI / CircleCI / Jenkins to GitHub Actions, fast,
with no broken merges.

## What's in the pack

Per source CI:
- BEFORE / AFTER worked examples (real configs side-by-side)
- MAPPING.md (every YAML/Jenkinsfile key -> GHA equivalent)

Plus:
- `tools/convert-travis.mjs` - best-effort .travis.yml -> ci.yml
  starter generator. Covers ~80% of node/python/go configs.
- `RUNBOOK.md` - the 4-phase migration plan with per-phase risk list.
- `README.md` (this file)

## Use it

1. Open the source-CI subfolder that matches your old tool.
2. Compare BEFORE / AFTER for the closest match to your config.
3. Use MAPPING.md to translate the rest of your config piece by piece.
4. Follow RUNBOOK.md for the cutover sequence so you don't break
   merges during the transition.

## Pair with the free CLIs

```
npx ci-doctor       # audit the migrated workflow
npx gha-budget      # project the new monthly cost
npx pin-actions     # rewrite uses: tags to SHAs
```

## License

See LICENSE.txt - single org, free updates within v1.x.
