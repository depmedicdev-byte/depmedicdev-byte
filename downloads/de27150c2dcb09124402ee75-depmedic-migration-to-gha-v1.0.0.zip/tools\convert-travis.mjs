#!/usr/bin/env node
/**
 * Convert a basic .travis.yml to a starter GitHub Actions workflow.
 * Best-effort - covers ~80% of common configs. Always review the output.
 *
 * Usage: node convert-travis.mjs path/to/.travis.yml
 */
import fs from 'node:fs';
import path from 'node:path';

const file = process.argv[2];
if (!file) { console.error('usage: node convert-travis.mjs <path/to/.travis.yml>'); process.exit(2); }
const text = fs.readFileSync(file, 'utf8');

function pluck(re) { const m = text.match(re); return m ? m[1] : null; }

const language = pluck(/^language:\s*(\w+)/m);
const nodeMatrix = (text.match(/^node_js:\s*\[([^\]]+)\]/m) || [])[1];
const pyMatrix   = (text.match(/^python:\s*\[([^\]]+)\]/m) || [])[1];
const goVersion  = (text.match(/^go:\s*\[?([^\n\]]+)\]?/m) || [])[1];
const cacheNpm   = /cache:\s*npm:\s*true/.test(text) || /cache:\s+- npm/.test(text);
const cachePip   = /cache:\s*pip:\s*true/.test(text);

const scriptBlock = (text.match(/script:\s*\n((?:\s+-.+\n?)+)/m) || [])[1] || '';
const scriptLines = scriptBlock.split('\n').map(l => l.replace(/^\s*-\s*/, '').trim()).filter(Boolean);

let setup = '';
if (language === 'node_js') {
  const versions = (nodeMatrix || '20').split(',').map(s => s.trim().replace(/['"]/g, ''));
  setup = `      - uses: actions/setup-node@60edb5dd545a775178f52524783378180af0d1f8
        with:
          node-version: \${{ matrix.node }}
          cache: ${cacheNpm ? 'npm' : ''}`.replace(/\s+cache: $/, '');
  var matrixBlock = `    strategy:
      fail-fast: true
      matrix:
        node: [${versions.join(', ')}]`;
} else if (language === 'python') {
  const versions = (pyMatrix || '"3.12"').split(',').map(s => s.trim().replace(/['"]/g, ''));
  setup = `      - uses: actions/setup-python@0a5c61591373683505ea898e09a3ea4f39ef2b9c
        with:
          python-version: \${{ matrix.python }}
          cache: ${cachePip ? 'pip' : ''}`.replace(/\s+cache: $/, '');
  var matrixBlock = `    strategy:
      fail-fast: true
      matrix:
        python: [${versions.map(v => `'${v}'`).join(', ')}]`;
} else if (language === 'go') {
  setup = `      - uses: actions/setup-go@cdcb36043654635271a94b9a6d1392de5bb323a7
        with:
          go-version: '${(goVersion || '1.22').trim().replace(/['"]/g, '')}'`;
  var matrixBlock = '';
} else {
  setup = '      # Travis language "' + language + '" - install toolchain manually here.';
  var matrixBlock = '';
}

const stepsYml = scriptLines.map(s => '      - run: ' + s).join('\n');

const out = `# Generated from .travis.yml by depmedic Migration Pack convert-travis.mjs.
# Review every line before committing.
name: ci
on:
  push: { branches: [main] }
  pull_request: { branches: [main] }

concurrency:
  group: \${{ github.workflow }}-\${{ github.ref }}
  cancel-in-progress: \${{ github.event_name == 'pull_request' }}

permissions:
  contents: read

jobs:
  test:
    runs-on: ubuntu-latest
    timeout-minutes: 15
${matrixBlock}
    steps:
      - uses: actions/checkout@b4ffde65f46336ab88eb53be808477a3936bae11
${setup}
${stepsYml}
`;

const dest = path.join(path.dirname(file), '.github', 'workflows');
fs.mkdirSync(dest, { recursive: true });
const outPath = path.join(dest, 'ci.yml');
fs.writeFileSync(outPath, out);
console.log('wrote ' + outPath);
console.log('next: review the file, then "npx ci-doctor" to audit it.');
