# Jenkins (declarative pipeline) -> GitHub Actions mapping

| Jenkins (Jenkinsfile)               | GitHub Actions                                          |
| ----------------------------------- | ------------------------------------------------------- |
| `pipeline { agent any }`          | `runs-on: ubuntu-latest` per job                      |
| `stages { stage('x') { ... } }`   | `jobs:` with `needs:` for ordering                  |
| `steps { sh '...' }`              | `steps: - run: ...`                                   |
| `environment { X = '...' }`       | `env:` (job-level or step-level)                      |
| `when { branch 'main' }`          | `if: github.ref == 'refs/heads/main'`                 |
| `when { tag 'v*' }`               | `if: startsWith(github.ref, 'refs/tags/v')`           |
| `triggers { cron(...) }`          | `on.schedule: [{ cron: '...' }]`                      |
| `triggers { pollSCM(...) }`       | `on.push` / `on.pull_request` (event-driven)        |
| `parameters { string(name: 'X') }`| `inputs:` on `workflow_dispatch:`                   |
| `withCredentials([...])`          | `secrets:` referenced as `${{ secrets.X }}`         |
| `archiveArtifacts ...`            | `actions/upload-artifact@v4`                          |
| `junit '...xml'`                  | A test reporter action (dorny/test-reporter, etc.)      |
| `post { always { ... } }`         | A trailing step with `if: always()`                   |
| `post { failure { mail ... } }`   | A job that depends on the failed job and `if: failure()`; or a notification action |
| `docker.build('img:tag').push()`  | `docker/build-push-action@v6`                         |
| Shared library (`@Library`)       | Reusable workflows (`uses: ./.github/workflows/x.yml`) or composite actions |
| Multi-branch pipeline               | The workflow already runs on every branch by default    |
| Parallel stages                     | Multiple jobs that don't `needs:` each other run in parallel |

## Things that need a real rethink
- **Approvals**: Jenkins `input` step -> GHA `environment:` with
  required reviewers. The UX moves from "wait inside the pipeline" to
  "the deploy job pauses for approval".
- **Notifications**: Jenkins built-in mailer -> Slack/Discord/email
  action. Pick one and standardize across repos.
- **Self-hosted agent labels**: Jenkins agent labels map to GHA runner
  labels (`runs-on: [self-hosted, my-label]`).
- **Plugin functionality**: Anything that depended on a Jenkins plugin
  needs an action equivalent. Search marketplace.github.com first.
