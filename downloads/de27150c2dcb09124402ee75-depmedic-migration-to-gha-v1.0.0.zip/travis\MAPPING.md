# Travis CI -> GitHub Actions mapping

| Travis YAML key            | GitHub Actions equivalent                                       |
| -------------------------- | --------------------------------------------------------------- |
| `language: node_js`      | `actions/setup-node` step                                     |
| `node_js: [16, 18, 20]`  | `strategy.matrix.node: [16, 18, 20]`                          |
| `cache: npm: true`       | `with: { cache: npm }` on setup-node                          |
| `script:`                | `steps:` with `run:`                                        |
| `before_install:`        | A run step *before* setup-node                                  |
| `install:`               | Usually `npm ci` step                                         |
| `deploy:`                | A separate job, often gated on `if: github.ref == 'refs/heads/main'` |
| `branches: only:`        | `on.push.branches`                                            |
| `branches: except:`      | `if: ${{ ... }}` on the job                                  |
| `env: matrix:`           | `strategy.matrix.<key>`                                       |
| `env: global:`           | Job-level `env:`                                              |
| `os:`                    | `strategy.matrix.os` + `runs-on: ${{ matrix.os }}`         |
| Encrypted env (`secure`) | Repo secrets, ref via `secrets.X`                             |
| `addons.apt.packages`    | `run: sudo apt-get install -y ...`                            |
| `if: branch = main`      | `if: github.ref == 'refs/heads/main'`                         |
| `if: NOT (type = pull_request)` | `if: github.event_name != 'pull_request'`              |
| Travis cron                | `on.schedule: [{ cron: '...' }]`                              |

## Things that have NO 1:1 mapping (and what to do)
- **`stages`**: GHA uses `needs:` for job DAGs, not stages. Map each
  stage to a job and chain with `needs`.
- **`allow_failures`**: GHA: per-matrix `continue-on-error: true`.
- **`fast_finish`**: Matrix `fail-fast: true` (default).
- **Travis built-in deploy providers**: GHA uses dedicated deploy actions
  (configure-aws-credentials, google-github-actions/auth, etc.). See the
  Security-First pack for OIDC variants.

## Gotchas
- Travis runs steps in a single shell; GHA runs each `run:` in a fresh
  shell. State (`export FOO=bar`) does not persist - use
  `echo "FOO=bar" >> $GITHUB_ENV`.
- Travis `$TRAVIS_PULL_REQUEST_BRANCH` -> GHA `github.head_ref`.
- Travis `$TRAVIS_BUILD_DIR` -> GHA `github.workspace`.
- Travis cache layout (npm cache vs. node_modules) - prefer
  `cache: npm` on setup-node which caches the npm cache, not modules.
