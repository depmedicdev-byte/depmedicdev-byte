# OIDC setup in one page

Long-lived secrets are the #1 way CI gets compromised. GitHub-OIDC lets
your workflow exchange a short-lived token (issued by GitHub for that
workflow run) for credentials at AWS / GCP / npm / PyPI / Cloudflare.

The trade-off: 5 minutes of one-time setup at the provider end, then
no more `*_TOKEN` secrets to rotate.

## The two mandatory bits

Every OIDC workflow needs:

```yaml
permissions:
  contents: read
  id-token: write   # let GitHub mint the OIDC token for this run
```

And then the provider-specific exchange step (below).

---

## npm Trusted Publishing

1. `npm login` once on your machine.
2. Visit the package on `npmjs.com` -> Settings -> Publishing access -> "Add Trusted Publisher".
3. Provider: `GitHub Actions`. Repo: `<owner>/<repo>`. Workflow filename: `release.yml` (or whatever your file is). Environment: optional but recommended.

Workflow step:
```yaml
      - uses: actions/setup-node@<sha>
        with:
          node-version: 20
          registry-url: 'https://registry.npmjs.org'
      - run: npm publish --provenance --access public
```
No `NPM_TOKEN` needed. `--provenance` adds an SLSA attestation to the package.

---

## PyPI Trusted Publishing

1. Visit `pypi.org/manage/account/publishing/` (you must own the project).
2. Add a "GitHub" publisher: owner, repo, workflow filename, environment name (e.g. `pypi`).
3. In your workflow, declare the same environment.

Workflow step:
```yaml
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/setup-python@<sha>
      - run: pip install build && python -m build
      - uses: pypa/gh-action-pypi-publish@<sha>
```
No `PYPI_API_TOKEN` needed.

---

## AWS

1. In your AWS account: IAM -> Identity providers -> Add provider.
   Type: OpenID Connect. URL: `https://token.actions.githubusercontent.com`.
   Audience: `sts.amazonaws.com`.
2. Create an IAM role with a trust policy that allows
   `token.actions.githubusercontent.com` for your specific
   `repo:<owner>/<repo>:ref:<ref>` (use a ref filter so other repos can't impersonate).
3. Attach whatever permissions the role needs.

Workflow step:
```yaml
      - uses: aws-actions/configure-aws-credentials@<sha>
        with:
          role-to-assume: arn:aws:iam::123456789012:role/MyGitHubOIDCRole
          aws-region: us-east-1
```

---

## Google Cloud (Workload Identity Federation)

1. In GCP: IAM -> Workload Identity Federation -> Create pool.
2. Add a provider: OIDC, issuer `https://token.actions.githubusercontent.com`,
   attribute mapping `google.subject = assertion.sub`,
   `attribute.repository = assertion.repository`.
3. Create a service account, then `gcloud iam service-accounts add-iam-policy-binding`
   to allow `principalSet://iam.googleapis.com/projects/<num>/locations/global/workloadIdentityPools/<pool>/attribute.repository/<owner>/<repo>`.

Workflow step:
```yaml
      - uses: google-github-actions/auth@<sha>
        with:
          workload_identity_provider: 'projects/123/.../providers/github'
          service_account: 'my-deploy-bot@my-project.iam.gserviceaccount.com'
```

---

## Cloudflare

Cloudflare doesn't accept OIDC directly yet. Use a scoped API token,
store it as a repo secret, and rotate it on a quarterly cron via the
Cloudflare API. Not as good as OIDC but the next-best thing.

---

## How to verify

After your first workflow run, check the job logs. The OIDC step
should print something like:
```
Authenticated as arn:aws:sts::...:assumed-role/MyGitHubOIDCRole/...
```
or:
```
Successfully published package@1.2.3 to https://registry.npmjs.org
```

If it fails: 99% of the time the trust-policy ref filter doesn't match.
Print `${{ github.ref }}` and `${{ github.repository }}` to confirm what
GitHub is sending, then update the trust policy to match.
