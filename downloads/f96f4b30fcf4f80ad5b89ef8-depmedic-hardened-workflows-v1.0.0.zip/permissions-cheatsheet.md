# `permissions:` cheatsheet

The `permissions:` block on every workflow controls what `GITHUB_TOKEN`
can do. The repo default is "write all" - which is way more than any
individual job needs. Set the workflow-level baseline to `contents: read`
and escalate per-job only where required.

## Default for every workflow

```yaml
permissions:
  contents: read
```

That's it. Every job inherits this. If a single job needs more, give
*just that job* extra permissions.

## Per-job recipes

### Push a comment to a PR
```yaml
jobs:
  comment:
    permissions:
      contents: read
      pull-requests: write
```

### Update / add a label
```yaml
jobs:
  label:
    permissions:
      contents: read
      pull-requests: write
      issues: write
```

### Push a release-please release PR
```yaml
jobs:
  release-please:
    permissions:
      contents: write
      pull-requests: write
```

### Create a GitHub Release with assets
```yaml
jobs:
  release:
    permissions:
      contents: write
```

### Publish to npm via OIDC Trusted Publishing
```yaml
jobs:
  publish:
    permissions:
      contents: read
      id-token: write
```

### Publish to PyPI via OIDC Trusted Publishing
```yaml
jobs:
  publish:
    permissions:
      contents: read
      id-token: write
    environment: pypi   # the env name configured at pypi.org
```

### Authenticate to AWS via OIDC
```yaml
jobs:
  deploy:
    permissions:
      contents: read
      id-token: write
```
Then in steps:
```yaml
      - uses: aws-actions/configure-aws-credentials@<sha>
        with:
          role-to-assume: arn:aws:iam::123:role/MyOIDCRole
          aws-region: us-east-1
```

### Authenticate to GCP via Workload Identity Federation
```yaml
jobs:
  deploy:
    permissions:
      contents: read
      id-token: write
```

### Push to ghcr.io
```yaml
jobs:
  docker:
    permissions:
      contents: read
      packages: write
```

### Code Scanning upload (SARIF)
```yaml
jobs:
  scan:
    permissions:
      contents: read
      security-events: write
```

### Push commits back to the same branch (rare, dangerous)
```yaml
jobs:
  bot-commit:
    permissions:
      contents: write
```
Prefer release-please or a Renovate-style flow over self-pushing.

## Things you almost never need

| permission | when |
|---|---|
| `actions: write` | Only if you trigger workflow_dispatch from a job. |
| `deployments: write` | Only if you create deployment objects manually. |
| `discussions: write` | Only if posting to GitHub Discussions. |
| `pages: write` | Only if calling the Pages API directly (not for `pages-build-deployment`). |
| `repository-projects: write` | Only if mutating Projects v1 / Projects v2. |

## How to audit your existing workflows

```
npx ci-doctor
```

The `missing-permissions` rule flags every workflow that doesn't set
this block at all. Fix is one paste of `permissions:\n  contents: read`
at the top of the file.
