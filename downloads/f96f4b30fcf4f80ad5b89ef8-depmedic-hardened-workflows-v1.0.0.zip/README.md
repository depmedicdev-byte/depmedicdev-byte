# depmedic Hardened Workflows Pack v1.0.0

Five production-grade GitHub Actions workflows you can drop into a new
repo today. Every line is opinionated. Every default is sane. Every
template passes all 14 ci-doctor rules out of the box.

## What's inside

| File | When to use |
|------|-------------|
| `node-library.yml` | Publishing an npm package. Test matrix on Node LTS, publish to npm on tag. |
| `node-app.yml` | Web app or API in Node. Test, build, deploy on `main`. |
| `python-library.yml` | Publishing a Python package to PyPI via OIDC trusted publishing. |
| `monorepo-affected.yml` | pnpm + turbo (or nx) monorepo. Only test packages affected by the PR. |
| `release-please.yml` | Conventional Commits to automatic semver releases. |

Plus:
- `permissions-cheatsheet.md` - the minimum `permissions:` block for the 12 most common job types.
- `oidc-setup.md` - one-page guide to GitHub-OIDC auth into AWS, GCP, PyPI, Cloudflare without long-lived secrets.

## Why these, why opinionated

These are the five workflow shapes I have set up over and over and
keep getting wrong in subtle ways. The patterns baked in:

- `concurrency` on every PR-triggered workflow with `cancel-in-progress: true` so a force-push doesn't pay for two runs.
- `timeout-minutes` on every job (default is 360 = 6 hours).
- `permissions:` set explicitly per workflow with `contents: read` baseline; escalated only on jobs that need it.
- All third-party actions pinned to a 40-char commit SHA with the original tag in a trailing comment.
- `actions/setup-*` always sets `cache: <ecosystem>`.
- `actions/cache` keys always include `hashFiles(...lockfile...)` so the cache invalidates when deps change.
- Matrix jobs always set `fail-fast: false`.
- Heavy steps gated by `paths:` filters or labels.
- `actions/checkout` defaults to `fetch-depth: 1` unless we explicitly need history.
- Artifacts always set `retention-days` (no 90-day default).
- OIDC wherever a long-lived secret is otherwise needed.

If you cherry-pick patterns from these templates instead of using them
as-is, run `npx ci-doctor` afterwards to make sure you didn't break a
rule. Every rule is documented at https://depmedicdev-byte.github.io/rules.html.

## Use

1. Pick the template that matches your project shape.
2. Copy it into `.github/workflows/<your-name>.yml`.
3. Edit the four `# CUSTOMIZE` markers (Node version, package name, deploy target, secret name).
4. Open a PR. The workflow runs.

## License

Templates: MIT. You can use, fork, modify, redistribute as you wish.
The README, USAGE, and curated content of this pack: licensed for
your team's internal use. Please don't repackage and resell as your
own product.

## Support

`depmedic.dev@gmail.com`. Bug in a template? Open an issue at
https://github.com/depmedicdev-byte/ci-doctor/issues - I'll fix it
and re-issue this pack.

## Companion

The 30-pattern cookbook explains the *why* behind every rule baked
into these templates. https://buy.polar.sh/polar_cl_E2HGFeAVxJ64gU0Tv0qGwAueuxvhuq6A0pjhE4BWTyD

## Changelog

### v1.0.0 - 2026-04-27
- Initial release. 5 templates, 2 reference docs.
