# Drop-in installer (PowerShell). Run from repo root.
$ErrorActionPreference = "Stop"

if (-not (Test-Path "package.json")) { throw "no package.json - run from repo root." }

Write-Host "= installing dev deps"
npm i -D husky lint-staged @commitlint/cli @commitlint/config-conventional

Write-Host "= installing husky"
npx husky install

Write-Host "= copying configs"
Copy-Item -Force configs/lintstagedrc.cjs ./.lintstagedrc.cjs
Copy-Item -Force configs/commitlint.config.cjs ./commitlint.config.cjs
Copy-Item -Force configs/.gitleaks.toml ./.gitleaks.toml
Copy-Item -Force .husky/pre-commit ./.husky/pre-commit
Copy-Item -Force .husky/commit-msg ./.husky/commit-msg
Copy-Item -Force .husky/pre-push ./.husky/pre-push
New-Item -ItemType Directory -Force scripts | Out-Null
Copy-Item -Force scripts/pre-pr.mjs ./scripts/pre-pr.mjs

node -e "const fs=require('fs');const p=JSON.parse(fs.readFileSync('package.json','utf8'));p.scripts=p.scripts||{};p.scripts['prepare']=p.scripts['prepare']||'husky install';p.scripts['pre-pr']=p.scripts['pre-pr']||'node ./scripts/pre-pr.mjs';fs.writeFileSync('package.json',JSON.stringify(p,null,2)+'\n');"

Write-Host "= done. run 'npm run pre-pr' before pushing."
