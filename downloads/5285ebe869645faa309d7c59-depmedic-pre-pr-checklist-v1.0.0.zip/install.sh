#!/usr/bin/env bash
# Drop-in installer. Run from the root of your repo.
set -euo pipefail

if [ ! -f "package.json" ]; then
  echo "no package.json - run from repo root."; exit 1
fi

echo "= installing dev deps"
npm i -D husky lint-staged @commitlint/cli @commitlint/config-conventional

echo "= installing husky"
npx husky install

echo "= copying configs"
cp -r .husky .husky-backup 2>/dev/null || true
cp -f configs/lintstagedrc.cjs ./.lintstagedrc.cjs
cp -f configs/commitlint.config.cjs ./commitlint.config.cjs
cp -f configs/.gitleaks.toml ./.gitleaks.toml
cp -f .husky/pre-commit ./.husky/pre-commit
cp -f .husky/commit-msg ./.husky/commit-msg
cp -f .husky/pre-push ./.husky/pre-push
chmod +x .husky/pre-commit .husky/commit-msg .husky/pre-push
mkdir -p scripts && cp -f scripts/pre-pr.mjs ./scripts/pre-pr.mjs

echo "= patching package.json scripts"
node -e "
  const fs = require('fs');
  const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
  pkg.scripts = pkg.scripts || {};
  pkg.scripts['prepare'] = pkg.scripts['prepare'] || 'husky install';
  pkg.scripts['pre-pr'] = pkg.scripts['pre-pr'] || 'node ./scripts/pre-pr.mjs';
  fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2) + '\n');
"

echo
echo "= done. run 'npm run pre-pr' before pushing."
