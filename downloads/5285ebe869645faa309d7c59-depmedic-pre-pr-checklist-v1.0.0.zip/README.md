# Pre-PR Checklist Pack v1.0.0

A drop-in pre-PR safety net for any Node.js / TypeScript repo.

## What you get

- **husky** hooks (pre-commit, commit-msg, pre-push)
- **lint-staged** running ESLint + Prettier only on staged files
- **commitlint** enforcing Conventional Commits
- **gitleaks** stopping secret commits at the source
- **ci-doctor** running on staged `.github/workflows/` changes
- **`npm run pre-pr`** - the same suite of checks your CI runs, locally,
  in under 60 seconds. Wired into the pre-push hook so a failing local
  check stops you from spamming CI.

## Install

```bash
# from your repo root
bash install.sh        # macOS / Linux
# or:
powershell ./install.ps1   # Windows
```

That's it. Next `git commit` will:
1. lint+format your staged files (no whole-repo passes)
2. scan for committed secrets (gitleaks)
3. validate the commit message (Conventional Commits)

Next `git push` will run `npm run pre-pr` which executes the same
ESLint + tsc + tests + ci-doctor + gitleaks suite that CI runs.

## File layout (after install)

```
.husky/
  pre-commit          # lint-staged + gitleaks
  commit-msg          # commitlint
  pre-push            # npm run pre-pr
.lintstagedrc.cjs
commitlint.config.cjs
.gitleaks.toml        # tune false positives
scripts/
  pre-pr.mjs          # the local mirror of CI
```

## Customization

- Edit `.lintstagedrc.cjs` to add language-specific commands (Python ruff,
  Go gofmt, etc. - templates already inside).
- Edit `commitlint.config.cjs` to tighten/loosen the type-enum or
  subject-max-length rules.
- Edit `.gitleaks.toml` to allowlist false positives or add custom
  org-token regexes.
- Edit `scripts/pre-pr.mjs` to add additional local checks.

## Why each piece is in the pack

- **husky**: standard, maintained, doesn't fight monorepos.
- **lint-staged**: 10-30x faster than full-repo lint on every commit;
  the only sustainable strategy on big repos.
- **commitlint**: pairs perfectly with conventional-commits-changelog and
  release-please for free auto-changelogs.
- **gitleaks**: catches the secret BEFORE it lands in git history. Once
  it's in history, you have to rotate the credential AND rewrite history.
- **ci-doctor**: catches workflow regressions (missing concurrency, a
  pinned-action-sha drift) at commit time, not in CI.
- **pre-pr script**: closes the loop - "what CI sees" should be runnable
  locally, in <60s, with one command.

## Pair with the free CLIs

```
npx ci-doctor    npx gha-budget    npx pin-actions    npx depmedic
```

## License

See LICENSE.txt - single org, free updates within v1.x.
