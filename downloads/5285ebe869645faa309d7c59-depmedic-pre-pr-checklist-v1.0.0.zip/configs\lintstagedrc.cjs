/**
 * lint-staged config: run only on staged files, never on the whole repo.
 * Tunes the slowest checkers to be fast on small staged sets.
 */
module.exports = {
  '*.{js,jsx,ts,tsx,mjs,cjs}': [
    'eslint --max-warnings=0 --fix',
    'prettier --write',
  ],
  '*.{json,md,yml,yaml,css,scss,html}': ['prettier --write'],
  '*.py': ['ruff check --fix --select ALL', 'ruff format'],
  '*.go':  ['gofmt -w', 'go vet'],
  '.github/workflows/*.{yml,yaml}': [
    'npx --yes ci-doctor',
  ],
};
