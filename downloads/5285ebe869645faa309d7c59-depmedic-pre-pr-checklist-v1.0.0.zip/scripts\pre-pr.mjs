#!/usr/bin/env node
/**
 * pre-pr: run the same checks CI runs, locally, in under 60 seconds.
 * Designed to be wired into 'npm run pre-pr' and the husky pre-push hook.
 *
 * Bails on the first failure. Prints a clean summary at the end.
 */
import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';

const t0 = Date.now();
const cwd = process.cwd();
const passes = []; const fails = [];

function step(name, cmd, args, opt = {}) {
  process.stdout.write('-> ' + name + ' ... ');
  const r = spawnSync(cmd, args, { cwd, stdio: 'pipe', shell: true, env: { ...process.env, ...opt.env } });
  if (r.status === 0) { console.log('ok'); passes.push(name); return true; }
  console.log('FAIL');
  if (r.stdout) process.stdout.write(r.stdout.toString());
  if (r.stderr) process.stderr.write(r.stderr.toString());
  fails.push(name);
  return false;
}

const hasScript = (name) => {
  try { return JSON.parse(require('node:fs').readFileSync('package.json', 'utf8')).scripts?.[name]; } catch { return null; }
};
const hasFile = (p) => existsSync(p);

const runChain = [];
if (hasFile('.eslintrc') || hasFile('.eslintrc.json') || hasFile('.eslintrc.cjs') || hasFile('eslint.config.js') || hasFile('eslint.config.mjs')) {
  runChain.push(['lint',       'npx', ['eslint', '--max-warnings=0', '.']]);
}
if (hasFile('tsconfig.json')) {
  runChain.push(['typecheck',  'npx', ['tsc', '--noEmit']]);
}
if (hasScript('test')) {
  runChain.push(['test',       'npm', ['test', '--silent']]);
}
if (hasFile('.github/workflows')) {
  runChain.push(['ci-doctor',  'npx', ['ci-doctor']]);
}
runChain.push(['gitleaks',   'npx', ['--yes', 'gitleaks', 'detect', '--source', '.', '--no-git', '-v', '--redact']]);

for (const [name, cmd, args] of runChain) {
  if (!step(name, cmd, args)) {
    console.error('\npre-pr: ' + fails.length + ' check failed - fix the above and re-run.');
    process.exit(1);
  }
}

const dt = ((Date.now() - t0) / 1000).toFixed(1);
console.log('\npre-pr: ' + passes.length + '/' + passes.length + ' passed in ' + dt + 's');
process.exit(0);
